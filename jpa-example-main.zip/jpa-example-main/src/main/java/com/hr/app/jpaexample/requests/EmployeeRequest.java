package com.hr.app.jpaexample.requests;

import lombok.Data;

/**
 * @author
 * @project jpa-example
 * @created on 14 Mar, 2023 09:16 pm
 */

@Data
public class EmployeeRequest {


}
